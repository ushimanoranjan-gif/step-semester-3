public class MaximumSubarray {
    static int maxSubArray(int[] nums) {
        int current = nums[0];   // best sum of a subarray ending at the current index
        int best = nums[0];
        for (int i = 1; i < nums.length; i++) {
            // Extend the running subarray, or restart from nums[i], whichever is larger
            current = Math.max(nums[i], current + nums[i]);
            best = Math.max(best, current);
        }
        return best;
    }

    public static void main(String[] args) {
        System.out.println(maxSubArray(new int[]{-2, 1, -3, 4, -1, 2, 1, -5, 4}));
        System.out.println(maxSubArray(new int[]{-3, -1, -2}));
    }
}
