import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ThreeSum {
    static int[][] threeSum(int[] input) {
        int[] nums = input.clone();
        Arrays.sort(nums);
        int n = nums.length;
        List<int[]> result = new ArrayList<>();

        for (int i = 0; i < n - 2; i++) {
            if (nums[i] > 0) break;                          // no way to reach 0 from here on
            if (i > 0 && nums[i] == nums[i - 1]) continue;   // skip duplicate first element

            int left = i + 1, right = n - 1;
            while (left < right) {
                int sum = nums[i] + nums[left] + nums[right];
                if (sum == 0) {
                    result.add(new int[]{nums[i], nums[left], nums[right]});
                    left++;
                    right--;
                    while (left < right && nums[left] == nums[left - 1]) left++;     // skip duplicate second
                    while (left < right && nums[right] == nums[right + 1]) right--;  // skip duplicate third
                } else if (sum < 0) {
                    left++;
                } else {
                    right--;
                }
            }
        }
        return result.toArray(new int[0][]);
    }

    public static void main(String[] args) {
        System.out.println(Arrays.deepToString(threeSum(new int[]{-1, 0, 1, 2, -1, -4})));
        System.out.println(Arrays.deepToString(threeSum(new int[]{0, 0, 0})));
        System.out.println(Arrays.deepToString(threeSum(new int[]{-2, 0, 0, 2, 2, -2, 0, 1, -1})));
    }
}
