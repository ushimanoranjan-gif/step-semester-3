import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.function.BiFunction;

abstract class BonusEmployee {
    protected final String name;
    protected final double monthlySalary;

    BonusEmployee(String name, double monthlySalary) {
        this.name = name;
        this.monthlySalary = monthlySalary;
    }

    String getName() { return name; }

    abstract double bonus();
}

class FullTimeEmployee extends BonusEmployee {
    FullTimeEmployee(String name, double salary) { super(name, salary); }
    double bonus() { return monthlySalary * 0.10; }
}

class PartTimeEmployee extends BonusEmployee {
    PartTimeEmployee(String name, double salary) { super(name, salary); }
    double bonus() { return monthlySalary * 0.05; }
}

class InternEmployee extends BonusEmployee {
    InternEmployee(String name, double salary) { super(name, salary); }
    double bonus() { return 2000.0; }       // fixed, ignores salary
}

public class FestivalBonus {
    public static void main(String[] args) throws IOException {
        Map<String, BiFunction<String, Double, BonusEmployee>> factory = new HashMap<>();
        factory.put("FULLTIME", FullTimeEmployee::new);
        factory.put("PARTTIME", PartTimeEmployee::new);
        factory.put("INTERN", InternEmployee::new);

        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(in.readLine().trim());
        double total = 0;
        for (int i = 0; i < n; i++) {
            String[] parts = in.readLine().trim().split("\\s+");
            BonusEmployee e = factory.get(parts[0].toUpperCase())
                                .apply(parts[1], Double.parseDouble(parts[2]));
            double bonus = e.bonus();
            total += bonus;
            System.out.println(String.format(Locale.US, "%s: %.2f", e.getName(), bonus));
        }
        System.out.println(String.format(Locale.US, "Total Bonus: %.2f", total));
    }
}
