import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.function.Function;

abstract class Room {
    protected final int units;

    Room(int units) { this.units = units; }

    abstract double bill();
}

class SingleRoom extends Room {
    SingleRoom(int units) { super(units); }
    double bill() { return 8.0 * units; }
}

class SharedRoom extends Room {
    private final int occupants;     // extra value lives inside the object itself

    SharedRoom(int units, int occupants) {
        super(units);
        this.occupants = occupants;
    }

    double bill() { return 6.0 * units / occupants; }       // per-occupant share
}

class ACRoom extends Room {
    ACRoom(int units) { super(units); }
    double bill() { return 10.0 * units + 200; }
}

public class HostelElectricityBill {
    public static void main(String[] args) throws IOException {
        // Each factory receives the tokens after the room type, so extra params stay inside it
        Map<String, Function<String[], Room>> factory = new HashMap<>();
        factory.put("SINGLE", p -> new SingleRoom(Integer.parseInt(p[0])));
        factory.put("SHARED", p -> new SharedRoom(Integer.parseInt(p[0]), Integer.parseInt(p[1])));
        factory.put("AC", p -> new ACRoom(Integer.parseInt(p[0])));

        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(in.readLine().trim());
        double total = 0;
        for (int i = 0; i < n; i++) {
            String[] parts = in.readLine().trim().split("\\s+");
            String type = parts[0].toUpperCase();
            Room r = factory.get(type).apply(Arrays.copyOfRange(parts, 1, parts.length));
            double bill = r.bill();
            total += bill;
            System.out.println(String.format(Locale.US, "%s: %.2f", type, bill));
        }
        System.out.println(String.format(Locale.US, "Total: %.2f", total));
    }
}
