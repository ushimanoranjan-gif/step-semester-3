import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BiFunction;

abstract class Plan {
    protected final String name;
    protected final LocalDate startDate;

    Plan(String name, LocalDate startDate) {
        this.name = name;
        this.startDate = startDate;
    }

    String getName() { return name; }

    abstract int validityDays();

    LocalDate renewalDate() {
        return startDate.plusDays(validityDays());   // plusDays handles leap years and year changes
    }
}

class BasicPlan extends Plan {
    BasicPlan(String name, LocalDate start) { super(name, start); }
    int validityDays() { return 30; }
}

class StandardPlan extends Plan {
    StandardPlan(String name, LocalDate start) { super(name, start); }
    int validityDays() { return 90; }
}

class PremiumPlan extends Plan {
    PremiumPlan(String name, LocalDate start) { super(name, start); }
    int validityDays() { return 365; }
}

public class StreamingRenewal {
    public static void main(String[] args) throws IOException {
        Map<String, BiFunction<String, LocalDate, Plan>> factory = new HashMap<>();
        factory.put("BASIC", BasicPlan::new);
        factory.put("STANDARD", StandardPlan::new);
        factory.put("PREMIUM", PremiumPlan::new);

        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(in.readLine().trim());
        for (int i = 0; i < n; i++) {
            String[] parts = in.readLine().trim().split("\\s+");
            Plan p = factory.get(parts[0].toUpperCase()).apply(parts[1], LocalDate.parse(parts[2]));
            System.out.println(p.getName() + ": " + p.renewalDate());   // LocalDate prints as YYYY-MM-DD
        }
    }
}
