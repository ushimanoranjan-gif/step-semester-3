import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.function.Function;

abstract class Customer {
    protected final double amount;

    Customer(double amount) { this.amount = amount; }

    abstract double finalAmount();
}

class StudentCustomer extends Customer {
    StudentCustomer(double amount) { super(amount); }
    double finalAmount() { return amount * 0.90; }          // 10% discount
}

class StaffCustomer extends Customer {
    StaffCustomer(double amount) { super(amount); }
    double finalAmount() { return amount * 0.95; }          // 5% discount
}

class GuestCustomer extends Customer {
    GuestCustomer(double amount) { super(amount); }
    double finalAmount() { return amount + 10; }            // Rs 10 service charge
}

public class CanteenBilling {
    public static void main(String[] args) throws IOException {
        // A new customer type only needs a new class and one entry here
        Map<String, Function<Double, Customer>> factory = new HashMap<>();
        factory.put("STUDENT", StudentCustomer::new);
        factory.put("STAFF", StaffCustomer::new);
        factory.put("GUEST", GuestCustomer::new);

        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(in.readLine().trim());
        double total = 0;
        for (int i = 0; i < n; i++) {
            String[] parts = in.readLine().trim().split("\\s+");
            String type = parts[0].toUpperCase();
            Customer c = factory.get(type).apply(Double.parseDouble(parts[1]));
            double bill = c.finalAmount();                  // polymorphic call
            total += bill;
            System.out.println(String.format(Locale.US, "%s: %.2f", type, bill));
        }
        System.out.println(String.format(Locale.US, "Total: %.2f", total));
    }
}
