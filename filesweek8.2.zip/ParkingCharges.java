import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.function.Function;

abstract class Vehicle {
    protected final int hours;

    Vehicle(int hours) { this.hours = hours; }

    abstract double charge();
}

class Bike extends Vehicle {
    Bike(int hours) { super(hours); }
    double charge() { return 10.0 * hours; }
}

class Car extends Vehicle {
    Car(int hours) { super(hours); }
    double charge() { return 30.0 + 20.0 * (hours - 1); }   // first hour Rs 30, then Rs 20 each
}

class Truck extends Vehicle {
    Truck(int hours) { super(hours); }
    double charge() { return Math.max(50.0 * hours, 100.0); } // minimum Rs 100
}

public class ParkingCharges {
    public static void main(String[] args) throws IOException {
        Map<String, Function<Integer, Vehicle>> factory = new HashMap<>();
        factory.put("BIKE", Bike::new);
        factory.put("CAR", Car::new);
        factory.put("TRUCK", Truck::new);

        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(in.readLine().trim());
        double total = 0;
        for (int i = 0; i < n; i++) {
            String[] parts = in.readLine().trim().split("\\s+");
            String type = parts[0].toUpperCase();
            Vehicle v = factory.get(type).apply(Integer.parseInt(parts[1]));
            double charge = v.charge();
            total += charge;
            System.out.println(String.format(Locale.US, "%s: %.2f", type, charge));
        }
        System.out.println(String.format(Locale.US, "Total: %.2f", total));
    }
}
