public class SeatingGridOptimizer {
    // Only computes one row's average; the caller decides Quiet vs Buzzing
    private static double rowAverage(int[] row) {
        if (row.length == 0) return 0;   // guard against an empty row in a jagged grid
        int sum = 0;
        for (int v : row) sum += v;
        return (double) sum / row.length;
    }

    static String classifyRows(int[][] seatingScores, int threshold) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < seatingScores.length; i++) {
            double avg = rowAverage(seatingScores[i]);   // called once per row
            if (i > 0) sb.append(" | ");
            sb.append("Row ").append(i).append(": ")
              .append(avg < threshold ? "Quiet Zone" : "Buzzing Zone");
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        int[][] grid = {
            {40, 50, 45},
            {85, 90, 95},
            {30, 20, 25}
        };
        System.out.println(classifyRows(grid, 60));
        // Jagged grid check
        System.out.println(classifyRows(new int[][]{{70}, {10, 20, 30, 40}, {}}, 60));
    }
}
