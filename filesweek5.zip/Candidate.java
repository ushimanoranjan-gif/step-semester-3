import java.util.Arrays;

public class Candidate implements Comparable<Candidate> {
    // Eligibility thresholds
    private static final double CGPA_DIRECT = 7.0;       // CGPA alone is enough
    private static final double CGPA_BORDERLINE = 6.5;   // minimum CGPA for the combined check
    private static final int CODING_BORDERLINE = 60;     // coding score needed to compensate

    // Encapsulated state
    private final String name;
    private final double cgpa;
    private final int codingScore;

    public Candidate(String name, double cgpa, int codingScore) {
        this.name = name;
        this.cgpa = cgpa;
        this.codingScore = codingScore;
    }

    public String getName() { return name; }
    public double getCgpa() { return cgpa; }
    public int getCodingScore() { return codingScore; }

    // Composite = CGPA x 10 + 0.5 x coding score (matches the sample: Aisha 102.0, Rohit 100.5, Karan 85.0)
    public double getCompositeScore() {
        return cgpa * 10 + 0.5 * codingScore;
    }

    // CGPA-only quick filter
    static boolean isEligible(double cgpa) {
        return cgpa >= CGPA_DIRECT;
    }

    // Combined filter: direct pass, or a borderline CGPA rescued by a strong coding score
    static boolean isEligible(double cgpa, int codingScore) {
        return isEligible(cgpa) || (cgpa >= CGPA_BORDERLINE && codingScore >= CODING_BORDERLINE);
    }

    // Descending by composite score, so Arrays.sort ranks the highest first
    @Override
    public int compareTo(Candidate other) {
        return Double.compare(other.getCompositeScore(), this.getCompositeScore());
    }

    static String shortlistAndRank(Candidate[] candidates) {
        // Count eligible candidates, then copy them into an array of exact size
        int count = 0;
        for (Candidate c : candidates) {
            if (isEligible(c.cgpa, c.codingScore)) count++;
        }
        if (count == 0) return "No candidates shortlisted";

        Candidate[] shortlisted = new Candidate[count];
        int idx = 0;
        for (Candidate c : candidates) {
            if (isEligible(c.cgpa, c.codingScore)) shortlisted[idx++] = c;
        }

        Arrays.sort(shortlisted);   // uses compareTo

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < shortlisted.length; i++) {
            if (i > 0) sb.append(" | ");
            sb.append(i + 1).append(". ").append(shortlisted[i].name)
              .append(" (").append(String.format("%.1f", shortlisted[i].getCompositeScore())).append(")");
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        Candidate[] batch = {
            new Candidate("Aisha", 8.2, 40),
            new Candidate("Rohit", 6.8, 65),
            new Candidate("Meena", 6.0, 90),
            new Candidate("Karan", 7.5, 20)
        };
        System.out.println(shortlistAndRank(batch));
    }
}
