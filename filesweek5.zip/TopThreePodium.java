import java.util.Arrays;

public class TopThreePodium {
    static int[] findTopThreeScores(int[] scores) {
        int first = Integer.MIN_VALUE, second = Integer.MIN_VALUE, third = Integer.MIN_VALUE;
        for (int s : scores) {
            if (s >= first) {            // new (or tied) highest: everyone shifts down
                third = second;
                second = first;
                first = s;
            } else if (s >= second) {    // new second place
                third = second;
                second = s;
            } else if (s > third) {      // new third place
                third = s;
            }
        }
        return new int[]{first, second, third};
    }

    public static void main(String[] args) {
        System.out.println(Arrays.toString(findTopThreeScores(new int[]{45, 82, 79, 90, 33, 90, 61})));
    }
}
