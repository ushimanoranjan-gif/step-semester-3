public class TransactionReference {
    // Trim, then uppercase only the first 3 characters (substring + concatenation)
    static String normalizeReference(String raw) {
        String t = raw.trim();
        if (t.length() < 3) return t;
        return t.substring(0, 3).toUpperCase() + t.substring(3);
    }

    static String validateAndFormat(String reference) {
        if (reference.length() != 14) {
            return "Invalid: wrong length (expected 14 characters)";
        }
        for (int i = 0; i < 3; i++) {
            if (!Character.isLetter(reference.charAt(i))) {
                return "Invalid: bank code must be 3 letters";
            }
        }
        for (int i = 3; i < 14; i++) {
            if (!Character.isDigit(reference.charAt(i))) {
                return "Invalid: date and sequence must be digits";
            }
        }
        String bank = reference.substring(0, 3);
        String date = reference.substring(3, 9);   // ddMMyy
        String seq = reference.substring(9);       // 5 digits
        StringBuilder sb = new StringBuilder();
        sb.append("[").append(bank).append("] DATE: ")
          .append(date.substring(0, 2)).append("/")
          .append(date.substring(2, 4)).append("/")
          .append(date.substring(4, 6))
          .append(" | SEQ: ").append(seq);
        return sb.toString();
    }

    public static void main(String[] args) {
        String[] inputs = {" hdf03022600042 ", "12F03022600042", "HDF0302260004", "HDF03O22600042"};
        for (String raw : inputs) {
            System.out.println(validateAndFormat(normalizeReference(raw)));
        }
    }
}
