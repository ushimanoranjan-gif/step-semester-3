public class PhoneMasker {
    static String maskPhoneNumber(String phone) {
        if (phone == null || phone.length() != 10) return "Invalid phone number";
        for (int i = 0; i < phone.length(); i++) {
            if (!Character.isDigit(phone.charAt(i))) return "Invalid phone number";
        }
        StringBuilder sb = new StringBuilder(phone.substring(6)); // last 4 digits
        sb.insert(0, "XXXXXX-");
        return sb.toString();
    }

    public static void main(String[] args) {
        System.out.println(maskPhoneNumber("9876543210"));
        System.out.println(maskPhoneNumber("98765"));
    }
}
