import sys
from abc import ABC, abstractmethod


class Delivery(ABC):
    def __init__(self, weight, distance):
        self.weight = weight
        self.distance = distance

    @abstractmethod
    def fee(self):
        ...


class StandardDelivery(Delivery):
    def fee(self):
        return 5 + 0.50 * self.weight + 0.10 * self.distance


class ExpressDelivery(Delivery):
    def fee(self):
        return 15 + 1.00 * self.weight + 0.20 * self.distance


class InternationalDelivery(Delivery):
    def __init__(self, weight, distance, customs_fee):
        super().__init__(weight, distance)
        self.customs_fee = customs_fee

    def fee(self):
        return 25 + 2.00 * self.weight + 0.50 * self.distance + self.customs_fee


DELIVERY_TYPES = {
    "STANDARD": StandardDelivery,
    "EXPRESS": ExpressDelivery,
    "INTERNATIONAL": InternationalDelivery,
}


def main():
    lines = sys.stdin.read().strip().splitlines()
    n = int(lines[0])
    total = 0.0
    for line in lines[1:n + 1]:
        parts = line.split()
        kind, numbers = parts[0].upper(), [float(x) for x in parts[1:]]
        delivery = DELIVERY_TYPES[kind](*numbers)   # extra param flows in as needed
        fee = delivery.fee()
        total += fee
        print(f"{kind}: {fee:.2f}")
    print(f"Total: {total:.2f}")


if __name__ == "__main__":
    main()
