import shlex
import sys
from abc import ABC, abstractmethod
from datetime import date, timedelta

CURRENT_DATE = date(2023, 10, 26)


class LibraryItem(ABC):
    def __init__(self, title):
        self.title = title

    @abstractmethod
    def loan_days(self):
        ...

    def due_date(self):
        return CURRENT_DATE + timedelta(days=self.loan_days())


class Book(LibraryItem):
    def loan_days(self):
        return 14


class DVD(LibraryItem):
    def loan_days(self):
        return 7


class Magazine(LibraryItem):
    def loan_days(self):
        return 3


ITEM_TYPES = {"BOOK": Book, "DVD": DVD, "MAGAZINE": Magazine}


def main():
    lines = sys.stdin.read().strip().splitlines()
    n = int(lines[0])
    for line in lines[1:n + 1]:
        kind, title = shlex.split(line)          # handles the quoted title
        item = ITEM_TYPES[kind.upper()](title)
        print(f"{item.title}: {item.due_date().strftime('%Y-%m-%d')}")


if __name__ == "__main__":
    main()
