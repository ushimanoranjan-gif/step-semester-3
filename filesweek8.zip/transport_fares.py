import sys
from abc import ABC, abstractmethod


class Journey(ABC):
    def __init__(self, distance):
        self.distance = distance

    @abstractmethod
    def fare(self):
        ...


class Bus(Journey):
    def fare(self):
        return min(2 + 0.10 * self.distance, 10)     # capped at $10


class Train(Journey):
    def fare(self):
        return 3 + 0.15 * self.distance


class Metro(Journey):
    def __init__(self, distance, peak_factor):
        super().__init__(distance)
        self.peak_factor = peak_factor

    def fare(self):
        return (1.50 + 0.20 * self.distance) * self.peak_factor


JOURNEY_TYPES = {"BUS": Bus, "TRAIN": Train, "METRO": Metro}


def main():
    lines = sys.stdin.read().strip().splitlines()
    n = int(lines[0])
    total = 0.0
    for line in lines[1:n + 1]:
        parts = line.split()
        kind, numbers = parts[0].upper(), [float(x) for x in parts[1:]]
        journey = JOURNEY_TYPES[kind](*numbers)
        fare = journey.fare()
        total += fare
        print(f"{kind}: {fare:.2f}")
    print(f"Total: {total:.2f}")


if __name__ == "__main__":
    main()
