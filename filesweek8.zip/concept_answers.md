# Concept Question Answers: Inheritance & Polymorphism

**1. Reuse and extension through inheritance.**
A derived class automatically gets the fields and methods of its base class, so shared logic is written once. It can then add new members or override inherited methods to specialize behavior. Example: a `BankAccount` base class has `deposit()` and `getBalance()`. `SavingsAccount` inherits both unchanged and adds `addInterest()`, while `CurrentAccount` overrides `withdraw()` to allow an overdraft.

**2. The "is-a" relationship.**
"Is-a" means every object of the derived class can legitimately stand in wherever the base class is expected: a `Car` is a `Vehicle`. It matters because inheritance promises substitutability. If the relationship is false (a `Stack` extending `ArrayList`, say), the subclass inherits operations that make no sense for it, and code that uses the base type can break. "Has-a" relationships (a `Library` has `Books`) should use composition instead.

**3. Method overriding.**
Overriding means a derived class provides its own implementation of a method with the same name and signature as one in its base class. Example: `Employee.calculateSalary()` returns the basic pay. `Manager` overrides it to add a bonus, `Intern` overrides it to return a fixed stipend, and `Contractor` overrides it to multiply hours by rate. Each class supplies its own calculation behind the same method name.

**4. Runtime polymorphism (dynamic dispatch).**
A base-type reference can point to any derived object. When a method is called, the actual object's class at runtime, not the reference's declared type, decides which override runs. In Java this is done through the object's class and its virtual method table. So `Animal a = new Dog(); a.makeSound();` runs `Dog`'s version.

**5. Polymorphic collections.**
A collection declared with a base type can hold objects of different derived types: `List<Payment> payments = List.of(new CardPayment(), new WalletPayment(), new BankTransferPayment());`. A single loop calling `calculateFee()` on each element runs the right version for each object. The advantages are uniform processing with no type checks, shorter code, and new types that fit in without changing the loop.

**6. Polymorphism vs. type-based conditionals.**
Both handle behavior that varies by type. With if-else or switch, the logic is centralized and must be edited for every new type, and each place that branches on type is another place to forget. With polymorphism, each type owns its behavior and the calling code stays the same. Polymorphism follows the open/closed principle (open for extension, closed for modification), is easier to test, and avoids long fragile chains of conditions.

**7. Adding new types with minimal change.**
The processing logic depends only on the base type (`Payment`) and its method (`calculateFee()`). To add a `CryptoPayment`, you write a new subclass that overrides `calculateFee()`, and the existing `PaymentProcessor` loop works with it unchanged, since it never mentions concrete types. Only the place where objects are created needs to know about the new class.

**8. Inherited vs. overridden behavior.**
Inherited behavior is used as-is from the base class. Overridden behavior replaces it with a specialized version. A derived class should inherit when the base implementation is already correct for it. Example: every `Employee` uses the same `getName()`. It should override when its behavior differs. Example: `Manager` overrides `calculateSalary()` to add a bonus.

**9. Inheritance purely for code reuse.**
Without a genuine "is-a" relationship, the subclass exposes inherited methods that don't make sense and breaks substitutability. It also creates tight coupling, because any change in the base class ripples into unrelated subclasses, and it makes the hierarchy rigid and confusing. Java allows only one base class, so this wastes the single inheritance slot. Composition or a shared utility class is the better way to reuse code.

**10. VehicleRental example.**
Common behavior shared by all rentals: `customerName`, `rentalDays`, `startRental()`, `endRental()`, and a `calculateCost()` method. Specialized behavior: `CarRental` charges a per-day rate and may add insurance, while `TruckRental` charges by day plus distance driven and may require a license check. A `VehicleRental` base class holds the shared fields and methods and declares `calculateCost()`. `CarRental` and `TruckRental` extend it and override `calculateCost()`, so billing code can loop over `VehicleRental` objects uniformly.
