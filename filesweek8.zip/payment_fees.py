import sys
from abc import ABC, abstractmethod


class Payment(ABC):
    def __init__(self, amount):
        self.amount = amount

    @abstractmethod
    def final_amount(self):
        ...


class CardPayment(Payment):
    def final_amount(self):
        return self.amount * 1.02          # 2% fee


class WalletPayment(Payment):
    def final_amount(self):
        return self.amount * 1.01          # 1% fee


class BankTransferPayment(Payment):
    def final_amount(self):
        return self.amount                 # no fee


# Registry: adding a new payment type only means adding a class and one entry here
PAYMENT_TYPES = {
    "CARD": CardPayment,
    "WALLET": WalletPayment,
    "BANKTRANSFER": BankTransferPayment,
}


def main():
    lines = sys.stdin.read().strip().splitlines()
    n = int(lines[0])
    total = 0.0
    for line in lines[1:n + 1]:
        kind, amount = line.split()
        payment = PAYMENT_TYPES[kind.upper()](float(amount))
        adjusted = payment.final_amount()       # polymorphic call, no type checks
        total += adjusted
        print(f"{kind.upper()}: {adjusted:.2f}")
    print(f"Total: {total:.2f}")


if __name__ == "__main__":
    main()
