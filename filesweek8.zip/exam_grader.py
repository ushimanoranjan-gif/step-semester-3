import shlex
import sys
from abc import ABC, abstractmethod


class Question(ABC):
    def __init__(self, text, correct, student, points):
        self.text = text
        self.correct = correct
        self.student = student
        self.points = points

    @abstractmethod
    def score(self):
        ...


class MCQ(Question):
    def score(self):
        return float(self.points) if self.student == self.correct else 0.0


class TrueFalse(Question):
    def score(self):
        return float(self.points) if self.student == self.correct else 0.0


class Essay(Question):
    def score(self):
        keywords = [k.strip().lower() for k in self.correct.split(",") if k.strip()]
        answer = self.student.lower()
        hits = sum(1 for k in keywords if k in answer)
        if hits >= 2:
            return self.points * 0.75
        if hits == 1:
            return self.points * 0.50
        return 0.0


QUESTION_TYPES = {"MCQ": MCQ, "TF": TrueFalse, "ESSAY": Essay}


def main():
    lines = sys.stdin.read().strip().splitlines()
    n = int(lines[0])
    total = 0.0
    for line in lines[1:n + 1]:
        kind, text, correct, student, points = shlex.split(line)
        q = QUESTION_TYPES[kind.upper()](text, correct, student, int(points))
        s = q.score()
        total += s
        print(f"{kind.upper()}: {s:.2f}")
    print(f"Total Score: {total:.2f}")


if __name__ == "__main__":
    main()
