public class MatchDayGridAnalyzer {
    // Only computes one match's average; the caller decides Power Surge vs Normal
    private static double rowAverage(int[] row) {
        if (row.length == 0) return 0;   // guard against a match with no overs logged
        int sum = 0;
        for (int runs : row) sum += runs;
        return (double) sum / row.length;
    }

    static String classifyMatches(int[][] runsPerOver, int threshold) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < runsPerOver.length; i++) {
            double avg = rowAverage(runsPerOver[i]);   // called once per match
            if (i > 0) sb.append(" | ");
            sb.append("Match ").append(i).append(": ")
              .append(avg >= threshold ? "Power Surge" : "Normal");
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        int[][] grid = {
            {4, 6, 8},
            {10, 12, 14},
            {2, 3, 1}
        };
        System.out.println(classifyMatches(grid, 8));
        // Jagged check: matches with different numbers of overs
        System.out.println(classifyMatches(new int[][]{{9}, {5, 6, 7, 8}, {20, 0}}, 8));
    }
}
