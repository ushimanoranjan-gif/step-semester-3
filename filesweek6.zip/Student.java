public class Student {
    String name;
    int attendance;

    static String collegeName = "SRM Institute of Science and Technology";
    static int studentCount = 0;

    Student(String name, int attendance) {
        this.name = name;
        this.attendance = attendance;
        studentCount++;   // once per object created
    }

    // Static: uses only static fields, never instance fields
    static void printCollegeInfo() {
        System.out.println(collegeName);
        System.out.println("Students created: " + studentCount);
    }

    public static void main(String[] args) {
        Student s1 = new Student("Ravi", 92);
        Student s2 = new Student("Anitha", 88);
        Student.printCollegeInfo();   // called through the class name
    }
}
