public final class NameTag {
    private final String firstName;
    private final String lastInitial;

    public NameTag(String fullName) {
        String[] parts = fullName.split(" ");   // split once, here only
        this.firstName = parts[0];
        this.lastInitial = parts[1].substring(0, 1);
    }

    public String getNickname() {
        return firstName + " " + lastInitial + ".";
    }

    public static void main(String[] args) {
        NameTag tag = new NameTag("Maria Gomez");
        System.out.println(tag.getNickname());                    // Maria G.
        NameTag other = new NameTag("Maria Gomez");
        System.out.println(tag.getNickname().equals(other.getNickname()));  // true: same behavior
        System.out.println(tag == other);                                   // false: separate objects
    }
}
