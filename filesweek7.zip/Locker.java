public class Locker {
    private final int lockerNumber;   // fixed at creation
    private String code;              // private, with no getter at all

    public Locker(int lockerNumber, String code) {
        this.lockerNumber = lockerNumber;
        this.code = code;
    }

    public int getLockerNumber() { return lockerNumber; }

    public boolean changeCode(String currentCode, String newCode) {
        if (!code.equals(currentCode)) {
            return false;             // wrong current code: do nothing else
        }
        code = newCode;
        return true;
    }

    public static void main(String[] args) {
        Locker l = new Locker(101, "1234");
        System.out.println(l.changeCode("1234", "5678") ? "success" : "rejected");
        System.out.println(l.changeCode("0000", "9999") ? "success" : "rejected");
        // The code can't be read, so prove it is still "5678" by using it:
        System.out.println("Code still 5678? " + l.changeCode("5678", "0001"));   // true
    }
}
