public class PiggyBank {
    private final String id;      // fixed the moment the object is created
    private double savings;       // private: only deposit/withdraw can change it

    public PiggyBank(String id) {
        this.id = id;
        this.savings = 0;         // a new piggy bank starts empty
    }

    public String getId() { return id; }

    public boolean deposit(double amount) {
        if (amount <= 0) return false;      // ignore zero/negative deposits
        savings += amount;
        return true;
    }

    public boolean withdraw(double amount) {
        if (amount <= 0 || amount > savings) return false;   // rejected: savings unchanged
        savings -= amount;
        return true;
    }

    public double getSavings() { return savings; }   // read-only; there is no setter

    public static void main(String[] args) {
        PiggyBank pb = new PiggyBank("PB-1");
        pb.deposit(100);
        System.out.println("After deposit(100): savings = " + pb.getSavings());
        pb.withdraw(30);
        System.out.println("After withdraw(30): savings = " + pb.getSavings());
        boolean ok = pb.withdraw(500);
        System.out.println("withdraw(500) " + (ok ? "applied" : "rejected")
                + ", savings stays " + pb.getSavings());
    }
}
