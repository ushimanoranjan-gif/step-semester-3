public class AttendanceSheet {
    private final String[] present;   // never returned to callers
    private int count = 0;

    public AttendanceSheet(int maxClassSize) {
        this.present = new String[maxClassSize];
    }

    public boolean markPresent(String name) {
        if (name == null || isPresent(name)) return false;   // no duplicates
        if (count >= present.length) return false;           // class is full
        present[count++] = name;
        return true;
    }

    public int getPresentCount() { return count; }

    public boolean isPresent(String name) {
        for (int i = 0; i < count; i++) {
            if (present[i].equals(name)) return true;
        }
        return false;
    }

    public static void main(String[] args) {
        AttendanceSheet sheet = new AttendanceSheet(30);
        sheet.markPresent("Ana");
        sheet.markPresent("Ben");
        sheet.markPresent("Ana");   // duplicate, ignored
        System.out.println("Present count: " + sheet.getPresentCount());       // 2
        System.out.println("isPresent(Ben): " + sheet.isPresent("Ben"));        // true
        System.out.println("isPresent(Chen): " + sheet.isPresent("Chen"));      // false
    }
}
