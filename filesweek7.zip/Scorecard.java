public class Scorecard {
    private final boolean[] results;   // never exposed in any form
    private int recorded = 0;          // how many answers recorded so far = next free slot

    public Scorecard(int totalQuestions) {
        this.results = new boolean[totalQuestions];   // question count fixed at creation
    }

    public boolean recordAnswer(boolean correct) {
        if (recorded >= results.length) return false;  // more answers than questions: rejected
        results[recorded++] = correct;
        return true;
    }

    // Only a number computed from the array leaves the class
    public int getScore() {
        int score = 0;
        for (int i = 0; i < recorded; i++) {
            if (results[i]) score++;
        }
        return score;
    }

    public static void main(String[] args) {
        Scorecard sc = new Scorecard(4);
        sc.recordAnswer(true);
        sc.recordAnswer(true);
        sc.recordAnswer(false);
        sc.recordAnswer(true);
        System.out.println("Score: " + sc.getScore());                                   // 3
        System.out.println("Extra answer accepted? " + sc.recordAnswer(true));           // false
        System.out.println("Score after extra attempt: " + sc.getScore());               // still 3
    }
}
